package com.bank.app;

public class PrintService {
	public static void printMenu() {
		System.out.println("      Hello, press:     ");

		System.out.println("1. Register a new account");
		System.out.println("2. Log in to your account");
		System.out.println("3. Exit");

	}

	public static void existAccountMenu() {
		System.out.println("       What would you like to do?       ");
		System.out.println("1. Info");
		System.out.println("2. Deposit money");
		System.out.println("3. Withdrawal money");
		System.out.println("4. Money transferring");
		System.out.println("5. Exit");

	}

}
